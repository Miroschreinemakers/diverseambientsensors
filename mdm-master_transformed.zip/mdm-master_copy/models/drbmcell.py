'''
The DRBM cell
'''

class BasicDRBMCell(object):

class LSTMDRBMCell(object):
    
class GRUDRBMCell(object):
